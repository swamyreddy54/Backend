var mongo= require('mongoose')
var schema = mongo.Schema;



var productSchema= new schema({
    productId:String,
    productName:String,
    productDes:String,
    productPrice:String,
})

var product=mongo.model('product',productSchema)
module.exports=product;
