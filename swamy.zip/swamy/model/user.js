var mongo=require('mongoose')
var Schema = mongo.Schema;

var userSchema=new Schema({
    userName:String,
    password:String,
    MobileNum:String,
})

var user=mongo.model('user',userSchema)
module.exports=user;