
var express=require('express');
var router=express.Router();
var product=require('../model/product');
const bodyparser = require('body-parser')

router.post('/product',(req,res)=>{
  var myproduct= new product({
    productId:req.body.productId,
    productName:req.body.productName,
    productDes:req.body.productDes,
    productPrice:req.body.productPrice
  })
  myproduct.save()
.then((p)=>{res.send(p)})
.catch((err)=>{console.log(err)})
})

router.get('/products',(req,res)=>{
  product.find({})
  .then((docs)=>{res.send(docs)})
  .catch((err)=>{console.log})
})

router.delete("/delete/:id",(req,res)=>{
var pid=req.params.id
product.findByIdAndDelete(pid)
.then((res)=>{res.send(res)})
.catch((err)=>{console.log(err)})
})

module.exports = router;