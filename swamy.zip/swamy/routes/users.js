var express = require('express');
var router = express.Router();
var user = require('../model/user')

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

router.post('/register', (req, res) => {
  var newuser = new user({
    userName: req.body.userName,
    password: req.body.password,
    MobileNum: req.body.MobileNum,
  })
  newuser.save()
    .then((res) => res.send(res))
    .catch((err) => console.log(err));
})

router.post('/login', (req, res) => {
  var _username = req.body.userName
  var _password = req.body.password

  user.findOne({ userName: _username }).select('_id userName password MobileNum')
    .then((doc) => {
      if (doc != null) {
        if (doc.password == _password) {
          res.send(doc)
        }
        else {
          res.send("-1");
        }
      }
      else{
        res.send("0")
      }
    })
})


module.exports = router;




